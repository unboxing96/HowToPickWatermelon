//
//  Trial.swift
//
//
//  Created by 김태현 on 2/22/24.
//

import Foundation

enum Trial {
    case good
    case bad
}
