//
//  TutorialPageContent.swift
//
//
//  Created by 김태현 on 2/21/24.
//

import Foundation

struct TutorialPageContent {
    let title: String
    let taste: [Taste]
}
