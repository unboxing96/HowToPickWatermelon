//
//  Answer.swift
//
//
//  Created by 김태현 on 2/22/24.
//

import Foundation

enum Answer {
    case undefined
    case correct
    case wrong
}
